import './Sidebar.css'

function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="intro">
        <h1 className="name">Shanmukha Thadavarthi</h1>
        <h2 className="role">Web Developer</h2>
        <p className="tagline">I craft web experiences with style & code.</p>
      </div>

      <nav className="nav-links">
        <a href="#about">About</a>
        <a href="#education">Education</a>
        <a href="#projects">Projects</a>
        <a href="#skills">Skills</a>
      </nav>

      <div className="social-icons">
        <a href="https://github.com/yourgithub" target="_blank" rel="noreferrer">
          <i className="fab fa-github"></i>
        </a>
        <a href="mailto:your@email.com">
          <i className="fas fa-envelope"></i>
        </a>
        <a href="https://linkedin.com/in/yourlinkedin" target="_blank" rel="noreferrer">
          <i className="fab fa-linkedin"></i>
        </a>
      </div>
    </aside>
  )
}

export default Sidebar
