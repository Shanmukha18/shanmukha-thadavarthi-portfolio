import './About.css'
import { motion } from 'framer-motion'

function About() {
  return (
    <section id="about" className="about-section">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
      >
        About Me
      </motion.h2>

      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        viewport={{ once: true }}
      >
        I'm a passionate frontend developer focused on crafting visually stunning
        and highly functional user interfaces. My work blends creativity with
        performance and accessibility, aiming to deliver impactful web experiences.
        I enjoy working with React, modern CSS, and building sleek UIs that users love.
      </motion.p>
    </section>
  )
}

export default About
