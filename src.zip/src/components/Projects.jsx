import './Projects.css'
import { motion } from 'framer-motion'

const projects = [
  {
    name: 'Portfolio Website',
    description: 'A personal portfolio built with React and Vite.',
    github: 'https://github.com/yourgithub/portfolio-site',
  },
  {
    name: 'Todo App',
    description: 'A clean, minimal task manager built with React and localStorage.',
    github: 'https://github.com/yourgithub/todo-app',
  },
  {
    name: 'Weather Dashboard',
    description: 'Weather app using OpenWeatherMap API and geolocation.',
    github: 'https://github.com/yourgithub/weather-dashboard',
  },
]

function Projects() {
  return (
    <section id="projects" className="projects-section">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
      >
        Projects
      </motion.h2>

      <div className="project-grid">
        {projects.map((project, index) => (
          <motion.div
            className="project-card"
            key={index}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            viewport={{ once: true }}
          >
            <h3>{project.name}</h3>
            <p>{project.description}</p>
            <a
              href={project.github}
              target="_blank"
              rel="noopener noreferrer"
              className="github-link"
            >
              View on GitHub →
            </a>
          </motion.div>
        ))}
      </div>
    </section>
  )
}

export default Projects
