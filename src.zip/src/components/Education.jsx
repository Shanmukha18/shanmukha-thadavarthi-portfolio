import './Education.css'
import { motion } from 'framer-motion'

const educationData = [
  {
    title: 'B.Tech in Computer Science',
    institution: 'ABC University',
    period: '2019 - 2023',
    description: 'Focused on frontend development, data structures, and software engineering.',
  },
  {
    title: 'Higher Secondary Education',
    institution: 'XYZ Junior College',
    period: '2017 - 2019',
    description: 'Studied Mathematics, Physics, and Computer Science.',
  },
]

function Education() {
  return (
    <section id="education" className="education-section">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
      >
        Education
      </motion.h2>

      <div className="timeline">
        {educationData.map((item, idx) => (
          <div className="timeline-item" key={idx}>
            <div className="timeline-dot" />
            <div className="timeline-content">
              <h3>{item.title}</h3>
              <h4>{item.institution}</h4>
              <span className="timeline-period">{item.period}</span>
              <p>{item.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

export default Education
