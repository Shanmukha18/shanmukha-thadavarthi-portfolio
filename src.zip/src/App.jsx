import Sidebar from './components/Sidebar'
import './styles/global.css'
import About from './components/About'
import Education from './components/Education'
import Projects from './components/Projects'

function App() {
  return (
    <div className="app">
      <div className="gradient-bg-blur" />
      <Sidebar />      
        <main className="main-content">
          <About />
          <Education />
          <Projects />
        </main>
    </div>
  )
}

export default App
